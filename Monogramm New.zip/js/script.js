$(document).ready(function(){

	$(window).scroll(function() {
		var height = $(window).scrollTop();
		if(height > 20){
			$('#header').addClass('none');
		} else{
			$('#header').removeClass('none');
		}
	});

	$(".owl-carousel").owlCarousel({
		 items: 1,
		 loop: true,
		 smartSpeed: 700,
		 nav: false,
		 lazyLoad: true,
		 autoHeight:true,
	});
	
	$("body").on('click', '[href*="#"]', function(e){
		 var fixed_offset = 100;
		 $('html,body').stop().animate({ scrollTop: $(this.hash).offset().top - fixed_offset }, 1000);
		 e.preventDefault();
	});


	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
	acc[i].addEventListener("click", function() {
		this.classList.toggle("active");
		var panel = this.nextElementSibling;
		if (panel.style.maxHeight){
			panel.style.maxHeight = null;
		} else {
			panel.style.maxHeight = panel.scrollHeight + "px";
		} 
	});
	}
});